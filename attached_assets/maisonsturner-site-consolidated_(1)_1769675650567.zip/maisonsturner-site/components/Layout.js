import Link from 'next/link';

/**
 * The Layout component wraps each page in a common header and footer.
 * It provides navigation and a consistent look and feel across the site.
 */
export default function Layout({ children }) {
  return (
    <>
      <header>
        {/* Display the brand logo instead of plain text. The image lives in the public folder and respects the
            height defined in globals.css via the .logo class. */}
        <Link href="/">
          {/* Wrapping in a span to avoid the default next/link styling on images */}
          <span>
            <img src="/logo.jpg" alt="Logo Maisons S‑Turner" className="logo" />
          </span>
        </Link>
        <nav>
          <ul>
            <li>
              <Link href="/">Accueil</Link>
            </li>
            <li>
              <Link href="/about">À&nbsp;propos</Link>
            </li>
            <li>
              <Link href="/models">Modèles</Link>
            </li>
            <li>
              <Link href="/realisations">Réalisations</Link>
            </li>
            <li>
              <Link href="/appointment">Rendez‑vous</Link>
            </li>
            <li>
              <Link href="/contact">Contact</Link>
            </li>
          </ul>
        </nav>
      </header>
      <main className="container">{children}</main>
      <footer>
        <p>&copy; {new Date().getFullYear()} Maisons S‑Turner. Tous droits réservés.</p>
      </footer>
    </>
  );
}