/**
 * Renders a JSON‑LD script tag for structured data. Accepts any JSON object.
 * See https://schema.org/ for details about possible schemas.
 */
export default function StructuredData({ data }) {
  if (!data) return null;
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}