// Liste des réalisations avec image et titre.
// Liste des réalisations avec image et titre.
// Ces entrées correspondent aux projets présentés dans la galerie.
const realisations = [
  { id: 1, title: 'Projet Athènes 2024', image: '/realisations/1.jpg' },
  { id: 2, title: 'Projet Oslo 2024', image: '/realisations/2.jpg' },
  { id: 3, title: 'Projet Prague 2024', image: '/realisations/3.jpg' },
  { id: 4, title: 'Projet Portofino 2024', image: '/realisations/4.jpg' },
  { id: 5, title: 'Projet Turenne 2024', image: '/realisations/5.jpg' },
  { id: 6, title: 'Projet Danemark 2024', image: '/realisations/6.jpg' },
];

export function getRealisations() {
  return realisations;
}