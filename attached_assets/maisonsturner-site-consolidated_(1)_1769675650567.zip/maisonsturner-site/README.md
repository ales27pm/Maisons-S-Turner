# Maisons S‑Turner — site web (refonte)

Refonte moderne (Next.js) orientée conversion + SEO local, avec formulaires qui envoient par courriel (sans chat temps réel).

## Inclus

- Nouveau branding : logo + palette harmonisée (variables CSS).
- Formulaire intelligent (Contact) : type de demande, type de maison, budget approximatif, région, échéancier.
- Page Prendre rendez‑vous : choix d’un modèle (facultatif), date/heure préférées, message.
- SEO local (Trois‑Rivières / Mauricie) : titres propres, pages structurées, balisage schema.org (LocalBusiness + Product).
- Galerie Réalisations : simple, clean, avec photos réelles du site.

## Démarrer en local

1) Copier l’environnement :

```bash
cp .env.example .env.local
```

2) Installer et lancer :

```bash
npm install
npm run dev
```

Puis ouvrir http://localhost:3000

## Envoi des formulaires par courriel

Les endpoints suivants envoient un courriel serveur‑side via SMTP :

- `POST /api/contact`
- `POST /api/appointment`

Configurer dans `.env.local` :

- `CONTACT_TO_EMAIL` (obligatoire)
- `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS` (obligatoires pour envoyer)
- `SMTP_FROM`, `SMTP_SECURE`, `CONTACT_CC_EMAIL` (optionnels)

Si SMTP n’est pas configuré, le serveur retourne `success: true` mais `mailed: false` et loggue la demande côté serveur.

## Déploiement

Ce projet est compatible Vercel, Netlify (avec adaptateur), ou un VPS Node. Sur Vercel, ajouter les variables d’environnement dans les settings du projet.
