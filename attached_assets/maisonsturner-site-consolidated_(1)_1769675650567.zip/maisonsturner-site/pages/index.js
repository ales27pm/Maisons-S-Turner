import Head from 'next/head';
import StructuredData from '../components/StructuredData';
import Link from 'next/link';
import Layout from '../components/Layout';
import { getAllModels } from '../data/models';

export default function HomePage() {
  const models = getAllModels();

  // Données de schema.org pour l'entreprise locale (SEO local)
  const localBusinessSchema = {
    '@context': 'https://schema.org',
    '@type': 'LocalBusiness',
    name: 'Maisons S‑Turner',
    description:
      'Conception et fabrication de maisons préfabriquées de qualité supérieure à Trois‑Rivières et en Mauricie.',
    url: 'https://www.maisonsturner.ca',
    telephone: '+1-555-555-5555',
    address: {
      '@type': 'PostalAddress',
      streetAddress: '123 Rue Exemple',
      addressLocality: 'Trois‑Rivières',
      addressRegion: 'QC',
      postalCode: 'G9A 1A1',
      addressCountry: 'CA',
    },
    geo: {
      '@type': 'GeoCoordinates',
      latitude: 46.344,
      longitude: -72.538,
    },
    openingHours: 'Mo-Fr 09:00-17:00',
  };
  return (
    <Layout>
      <Head>
        <title>Maisons S‑Turner | Accueil</title>
        <meta name="description" content="Maisons préfabriquées de qualité à Trois‑Rivières" />
      </Head>
      {/* Schema.org local business for SEO */}
      <StructuredData data={localBusinessSchema} />
      <section className="hero" style={{ backgroundImage: `url('/placeholder-hero.jpg')` }}>
        <h1>Votre maison de rêve sur mesure</h1>
        <p>
          Faites confiance à Maisons S‑Turner pour la conception et la fabrication de votre maison préfabriquée de qualité supérieure.
        </p>
        <Link href="/models" className="btn">
          Découvrir nos modèles
        </Link>
      </section>
      <h2 style={{ marginTop: '3rem' }}>Nos modèles en vedette</h2>
      <div className="grid">
        {models.map((model) => (
          <div key={model.slug} className="card">
            <img src={model.image} alt={model.name} />
            <div className="card-content">
              <div className="card-title">{model.name}</div>
              <div className="card-description">{model.description}</div>
              <div className="card-action">
                <Link href={`/models/${model.slug}`} className="btn">
                  Voir plus
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </Layout>
  );
}