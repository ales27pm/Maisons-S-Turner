import { useState } from 'react';
import Head from 'next/head';
import Layout from '../components/Layout';
import { useRouter } from 'next/router';

export default function ContactPage() {
  const router = useRouter();
  const { model } = router.query;

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    /**
     * type de demande : Information, Service après‑vente, Demande de soumission, Autre
     */
    category: model ? 'Demande de soumission' : '',
    /**
     * type de maison : Chalet, Plain‑pied, Deux étages, Autre
     */
    houseType: '',
    /**
     * budget approximatif sous forme de chaîne (ex. "200000", "300‑400k")
     */
    budget: '',
    /**
     * région desservie : Trois‑Rivières, Mauricie, etc.
     */
    region: '',
    /**
     * échéancier du projet : Immédiate, 3 à 6 mois, etc.
     */
    timeline: '',
    subject: model ? `Information sur le modèle ${model}` : '',
    message: '',
  });
  const [status, setStatus] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus('pending');
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });
      if (res.ok) {
        setStatus('success');
        // Réinitialiser tous les champs à leurs valeurs par défaut
        setFormData({
          name: '',
          email: '',
          phone: '',
          category: '',
          houseType: '',
          budget: '',
          region: '',
          timeline: '',
          subject: '',
          message: '',
        });
      } else {
        throw new Error('Échec de l’envoi');
      }
    } catch (err) {
      console.error(err);
      setStatus('error');
    }
  };

  return (
    <Layout>
      <Head>
        <title>Contact | Maisons S‑Turner</title>
        <meta name="description" content="Contactez l’équipe de Maisons S‑Turner pour toute question ou demande de soumission." />
      </Head>
      <h1>Contactez‑nous</h1>
      <p>
        Vous avez des questions sur nos modèles ou souhaitez obtenir une soumission? Remplissez le formulaire ci‑dessous et nous vous répondrons dans les plus brefs délais.
      </p>
      <form onSubmit={handleSubmit} noValidate>
        <div className="form-group">
          <label htmlFor="name">Nom</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">Courriel</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="phone">Téléphone</label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="category">Type de demande</label>
          <select
            id="category"
            name="category"
            value={formData.category}
            onChange={handleChange}
            required
          >
            <option value="">Veuillez choisir</option>
            <option value="Information">Information sur un modèle</option>
            <option value="Service après‑vente">Service après‑vente</option>
            <option value="Demande de soumission">Demande de soumission</option>
            <option value="Autre">Autre</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="houseType">Type de maison</label>
          <select
            id="houseType"
            name="houseType"
            value={formData.houseType}
            onChange={handleChange}
          >
            <option value="">Veuillez choisir</option>
            <option value="Chalet">Chalet</option>
            <option value="Plain‑pied">Plain‑pied</option>
            <option value="Deux étages">Deux étages</option>
            <option value="Autre">Autre</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="budget">Budget approximatif</label>
          <input
            type="text"
            id="budget"
            name="budget"
            placeholder="ex. 250 000 $"
            value={formData.budget}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="region">Région</label>
          <select
            id="region"
            name="region"
            value={formData.region}
            onChange={handleChange}
          >
            <option value="">Veuillez choisir</option>
            <option value="Trois‑Rivières">Trois‑Rivières</option>
            <option value="Mauricie">Mauricie</option>
            <option value="Capitale‑Nationale">Capitale‑Nationale</option>
            <option value="Autre">Autre</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="timeline">Échéancier</label>
          <select
            id="timeline"
            name="timeline"
            value={formData.timeline}
            onChange={handleChange}
          >
            <option value="">Veuillez choisir</option>
            <option value="Immédiate">Immédiate</option>
            <option value="3 à 6 mois">3 à 6 mois</option>
            <option value="6 à 12 mois">6 à 12 mois</option>
            <option value="Plus de 12 mois">Plus de 12 mois</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="subject">Sujet</label>
          <input
            type="text"
            id="subject"
            name="subject"
            value={formData.subject}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="message">Message</label>
          <textarea
            id="message"
            name="message"
            value={formData.message}
            onChange={handleChange}
            required
          ></textarea>
        </div>
        <button type="submit" className="form-submit">
          Envoyer
        </button>
        {status === 'pending' && <p>Envoi en cours…</p>}
        {status === 'success' && <p>Merci! Votre message a été envoyé.</p>}
        {status === 'error' && <p>Une erreur est survenue, veuillez réessayer.</p>}
      </form>
    </Layout>
  );
}