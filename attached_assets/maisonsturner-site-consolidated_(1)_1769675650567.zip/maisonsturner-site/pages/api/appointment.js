import { sendMail } from '../../lib/mailer';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function s(v) {
  if (v === undefined || v === null) return '';
  return String(v).trim();
}

function escapeHtml(str) {
  return str
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function htmlRow(label, value) {
  const val = s(value);
  if (!val) return '';
  return `<tr><td style="padding:6px 10px; font-weight:600; white-space:nowrap;">${label}</td><td style="padding:6px 10px;">${escapeHtml(val)}</td></tr>`;
}

/**
 * API route – prise de rendez-vous.
 * Envoie un courriel au destinataire configuré.
 */
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end(`Méthode ${req.method} non autorisée`);
  }

  const { name, email, phone, modelSlug, date, time, message } = req.body || {};
  const _name = s(name);
  const _email = s(email);
  const _date = s(date);
  const _time = s(time);
  const _message = s(message);

  if (!_name || !_email || !_date || !_time) {
    return res.status(400).json({ error: 'Les champs nom, courriel, date et heure sont requis.' });
  }
  if (!EMAIL_RE.test(_email)) {
    return res.status(400).json({ error: 'Adresse courriel invalide.' });
  }

  const model = s(modelSlug);
  const subj = `Demande de rendez-vous – ${_date} ${_time}`;

  const text = [
    'DEMANDE DE RENDEZ-VOUS – MAISONS S‑TURNER',
    '',
    `Nom: ${_name}`,
    `Courriel: ${_email}`,
    phone ? `Téléphone: ${s(phone)}` : '',
    model ? `Modèle souhaité: ${model}` : '',
    `Date préférée: ${_date}`,
    `Heure préférée: ${_time}`,
    '',
    _message ? 'Message:' : '',
    _message,
  ].filter(Boolean).join('\n');

  const html = `
    <div style="font-family:Arial,Helvetica,sans-serif; line-height:1.4; color:#111;">
      <h2 style="margin:0 0 12px 0;">Demande de rendez-vous – Maisons S‑Turner</h2>
      <p style="margin:0 0 12px 0;"><strong>Date / Heure :</strong> ${escapeHtml(_date)} ${escapeHtml(_time)}</p>
      <table style="border-collapse:collapse; border:1px solid #e5e5e5;">
        <tbody>
          ${htmlRow('Nom', _name)}
          ${htmlRow('Courriel', _email)}
          ${htmlRow('Téléphone', phone)}
          ${htmlRow('Modèle souhaité', model)}
          ${htmlRow('Date', _date)}
          ${htmlRow('Heure', _time)}
        </tbody>
      </table>
      ${_message ? `<h3 style="margin:16px 0 8px 0;">Message</h3>
        <div style="white-space:pre-wrap; padding:12px; border:1px solid #e5e5e5; border-radius:6px; background:#fafafa;">${escapeHtml(_message)}</div>` : ''}
    </div>
  `;

  const result = await sendMail({
    subject: `[Maisons S‑Turner] ${subj} – ${_name}`,
    text,
    html,
    replyTo: _email,
  });

  console.log('Appointment request', {
    name: _name,
    email: _email,
    phone: s(phone),
    modelSlug: model,
    date: _date,
    time: _time,
    mailed: result.ok,
  });

  return res.status(200).json({ success: true, mailed: result.ok });
}
