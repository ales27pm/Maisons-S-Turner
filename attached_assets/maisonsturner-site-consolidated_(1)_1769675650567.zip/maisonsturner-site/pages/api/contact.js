import { sendMail } from '../../lib/mailer';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function s(v) {
  if (v === undefined || v === null) return '';
  return String(v).trim();
}

function field(label, value) {
  const val = s(value);
  if (!val) return '';
  return `${label}: ${val}`;
}

function htmlRow(label, value) {
  const val = s(value);
  if (!val) return '';
  return `<tr><td style="padding:6px 10px; font-weight:600; white-space:nowrap;">${label}</td><td style="padding:6px 10px;">${escapeHtml(val)}</td></tr>`;
}

function escapeHtml(str) {
  return str
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

/**
 * API route – formulaire de contact "intelligent".
 * Envoie un courriel au destinataire configuré.
 */
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end(`Méthode ${req.method} non autorisée`);
  }

  const {
    name,
    email,
    phone,
    subject,
    message,
    category,
    houseType,
    budget,
    region,
    timeline,
  } = req.body || {};

  const _name = s(name);
  const _email = s(email);
  const _message = s(message);

  if (!_name || !_email || !_message) {
    return res.status(400).json({ error: 'Veuillez fournir les champs requis (nom, courriel, message).' });
  }
  if (!EMAIL_RE.test(_email)) {
    return res.status(400).json({ error: 'Adresse courriel invalide.' });
  }

  const kind = s(category) || 'Contact';
  const subj = s(subject) || `Nouvelle demande – ${kind}`;

  const lines = [
    'NOUVELLE DEMANDE – MAISONS S‑TURNER',
    '',
    field('Type de demande', kind),
    field('Nom', _name),
    field('Courriel', _email),
    field('Téléphone', phone),
    field('Type de maison', houseType),
    field('Budget', budget),
    field('Région', region),
    field('Échéancier', timeline),
    field('Sujet', subj),
    '',
    'Message:',
    _message,
  ].filter(Boolean);

  const html = `
    <div style="font-family:Arial,Helvetica,sans-serif; line-height:1.4; color:#111;">
      <h2 style="margin:0 0 12px 0;">Nouvelle demande – Maisons S‑Turner</h2>
      <p style="margin:0 0 12px 0;"><strong>Type de demande :</strong> ${escapeHtml(kind)}</p>
      <table style="border-collapse:collapse; border:1px solid #e5e5e5;">
        <tbody>
          ${htmlRow('Nom', _name)}
          ${htmlRow('Courriel', _email)}
          ${htmlRow('Téléphone', phone)}
          ${htmlRow('Type de maison', houseType)}
          ${htmlRow('Budget', budget)}
          ${htmlRow('Région', region)}
          ${htmlRow('Échéancier', timeline)}
          ${htmlRow('Sujet', subj)}
        </tbody>
      </table>
      <h3 style="margin:16px 0 8px 0;">Message</h3>
      <div style="white-space:pre-wrap; padding:12px; border:1px solid #e5e5e5; border-radius:6px; background:#fafafa;">${escapeHtml(_message)}</div>
    </div>
  `;

  // Envoi mail (fallback en log si SMTP non configuré).
  const result = await sendMail({
    subject: `[Maisons S‑Turner] ${subj} (${kind}) – ${_name}`,
    text: lines.join('\n'),
    html,
    replyTo: _email,
  });

  // On loggue aussi côté serveur pour audit minimal.
  console.log('Contact form submission', {
    name: _name,
    email: _email,
    phone: s(phone),
    category: kind,
    houseType: s(houseType),
    budget: s(budget),
    region: s(region),
    timeline: s(timeline),
    subject: subj,
    mailed: result.ok,
  });

  return res.status(200).json({ success: true, mailed: result.ok });
}
