import Head from 'next/head';
import Layout from '../components/Layout';
import { getRealisations } from '../data/realisations';

/**
 * Page des réalisations (portefolio) des projets terminés de Maisons S‑Turner.
 */
export default function RealisationsPage() {
  const items = getRealisations();
  return (
    <Layout>
      <Head>
        <title>Réalisations | Maisons S‑Turner</title>
        <meta name="description" content="Découvrez quelques‑unes de nos réalisations récentes." />
      </Head>
      <h1>Nos réalisations</h1>
      <p>Voici un aperçu de projets récemment construits pour nos clients. Chaque maison reflète notre savoir‑faire et notre attention aux détails.</p>
      <div className="grid">
        {items.map((item) => (
          <div key={item.id} className="card">
            <img src={item.image} alt={item.title} />
            <div className="card-content">
              <div className="card-title">{item.title}</div>
            </div>
          </div>
        ))}
      </div>
    </Layout>
  );
}