import { useState } from 'react';
import Head from 'next/head';
import Layout from '../components/Layout';
import { getAllModels } from '../data/models';

/**
 * Page permettant aux visiteurs de prendre rendez‑vous avec un conseiller.
 * Le formulaire envoie les informations vers l'API /api/appointment.
 */
export default function AppointmentPage() {
  const models = getAllModels();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    modelSlug: '',
    date: '',
    time: '',
    message: '',
  });
  const [status, setStatus] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus('pending');
    try {
      const res = await fetch('/api/appointment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });
      if (res.ok) {
        setStatus('success');
        setFormData({ name: '', email: '', phone: '', modelSlug: '', date: '', time: '', message: '' });
      } else {
        throw new Error('Échec de l’envoi');
      }
    } catch (err) {
      console.error(err);
      setStatus('error');
    }
  };

  return (
    <Layout>
      <Head>
        <title>Prendre rendez‑vous | Maisons S‑Turner</title>
        <meta name="description" content="Planifiez un rendez‑vous avec un conseiller pour discuter de votre projet de maison." />
      </Head>
      <h1>Prendre rendez‑vous</h1>
      <p>Choisissez un moment qui vous convient pour rencontrer un membre de notre équipe et discuter de votre projet.</p>
      <form onSubmit={handleSubmit} noValidate>
        <div className="form-group">
          <label htmlFor="name">Nom</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">Courriel</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="phone">Téléphone</label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="modelSlug">Modèle souhaité (facultatif)</label>
          <select id="modelSlug" name="modelSlug" value={formData.modelSlug} onChange={handleChange}>
            <option value="">Aucun en particulier</option>
            {models.map((m) => (
              <option key={m.slug} value={m.slug}>
                {m.name}
              </option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="date">Date préférée</label>
          <input
            type="date"
            id="date"
            name="date"
            value={formData.date}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="time">Heure préférée</label>
          <input
            type="time"
            id="time"
            name="time"
            value={formData.time}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="message">Message / Commentaires</label>
          <textarea
            id="message"
            name="message"
            value={formData.message}
            onChange={handleChange}
            placeholder="Expliquez brièvement votre projet..."
          ></textarea>
        </div>
        <button type="submit" className="form-submit">
          Envoyer la demande
        </button>
        {status === 'pending' && <p>Envoi en cours…</p>}
        {status === 'success' && <p>Votre demande de rendez‑vous a été envoyée.</p>}
        {status === 'error' && <p>Une erreur est survenue, veuillez réessayer.</p>}
      </form>
    </Layout>
  );
}