import Head from 'next/head';
import Link from 'next/link';
import Layout from '../../components/Layout';
import { getAllModels } from '../../data/models';

export default function ModelsPage() {
  const models = getAllModels();

  // Group models by category for display
  const categories = models.reduce((acc, model) => {
    if (!acc[model.category]) acc[model.category] = [];
    acc[model.category].push(model);
    return acc;
  }, {});

  const categoryLabels = {
    'plain-pied': 'Plain‑pied',
    chalet: 'Chalet',
    'deux-etages': 'Deux étages',
  };

  return (
    <Layout>
      <Head>
        <title>Nos modèles | Maisons S‑Turner</title>
        <meta name="description" content="Découvrez tous nos modèles de maisons préfabriquées." />
      </Head>
      <h1>Nos modèles</h1>
      {Object.keys(categories).map((cat) => (
        <section key={cat} style={{ marginTop: '2rem' }}>
          <h2>{categoryLabels[cat] ?? cat}</h2>
          <div className="grid">
            {categories[cat].map((model) => (
              <div key={model.slug} className="card">
                <img src={model.image} alt={model.name} />
                <div className="card-content">
                  <div className="card-title">{model.name}</div>
                  <div className="card-description">{model.description}</div>
                  <div className="card-action">
                    <Link href={`/models/${model.slug}`} className="btn">
                      Voir le modèle
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      ))}
    </Layout>
  );
}