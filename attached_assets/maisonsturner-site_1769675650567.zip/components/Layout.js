import Link from 'next/link';

/**
 * The Layout component wraps each page in a common header and footer.
 * It provides navigation and a consistent look and feel across the site.
 */
export default function Layout({ children }) {
  return (
    <>
      <header>
        <Link href="/">
          <h1 style={{ margin: 0, fontSize: '1.5rem', fontWeight: 600 }}>Maisons S‑Turner</h1>
        </Link>
        <nav>
          <ul>
            <li>
              <Link href="/">Accueil</Link>
            </li>
            <li>
              <Link href="/about">À&nbsp;propos</Link>
            </li>
            <li>
              <Link href="/models">Modèles</Link>
            </li>
            <li>
              <Link href="/contact">Contact</Link>
            </li>
          </ul>
        </nav>
      </header>
      <main className="container">{children}</main>
      <footer>
        <p>&copy; {new Date().getFullYear()} Maisons S‑Turner. Tous droits réservés.</p>
      </footer>
    </>
  );
}