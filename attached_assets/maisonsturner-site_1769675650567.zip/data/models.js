// Sample data representing the different house models offered by Maisons S‑Turner.
// In a real application this data would be fetched from a CMS or database.

const models = [
  {
    slug: 'oslo',
    name: 'Oslo',
    category: 'plain-pied',
    image: '/models/oslo.jpg',
    description:
      'Modèle plain‑pied lumineux avec une aire ouverte et des finitions modernes. Parfait pour les familles à la recherche de confort et de style.',
    features: ['2 chambres', '1 salle de bain', 'Aire ouverte'],
  },
  {
    slug: 'prague',
    name: 'Prague',
    category: 'chalet',
    image: '/models/prague.jpg',
    description:
      'Modèle chalet avec un design chaleureux et une terrasse intégrée. Idéal pour les escapades en nature.',
    features: ['3 chambres', '2 salles de bain', 'Mezzanine'],
  },
  {
    slug: 'berlin',
    name: 'Berlin',
    category: 'deux-etages',
    image: '/models/berlin.jpg',
    description:
      'Modèle à deux étages au style contemporain offrant un grand espace de vie et des matériaux de qualité.',
    features: ['4 chambres', '2.5 salles de bain', 'Garage attenant'],
  },
];

export function getAllModels() {
  return models;
}

export function getModelBySlug(slug) {
  return models.find((model) => model.slug === slug);
}