import { useState } from 'react';
import Head from 'next/head';
import Layout from '../components/Layout';
import { useRouter } from 'next/router';

export default function ContactPage() {
  const router = useRouter();
  const { model } = router.query;

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: model ? `Information sur le modèle ${model}` : '',
    message: '',
    category: model ? 'Demande de soumission' : '',
  });
  const [status, setStatus] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus('pending');
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });
      if (res.ok) {
        setStatus('success');
        setFormData({ name: '', email: '', phone: '', subject: '', message: '', category: '' });
      } else {
        throw new Error('Échec de l’envoi');
      }
    } catch (err) {
      console.error(err);
      setStatus('error');
    }
  };

  return (
    <Layout>
      <Head>
        <title>Contact | Maisons S‑Turner</title>
        <meta name="description" content="Contactez l’équipe de Maisons S‑Turner pour toute question ou demande de soumission." />
      </Head>
      <h1>Contactez‑nous</h1>
      <p>
        Vous avez des questions sur nos modèles ou souhaitez obtenir une soumission? Remplissez le formulaire ci‑dessous et nous vous répondrons dans les plus brefs délais.
      </p>
      <form onSubmit={handleSubmit} noValidate>
        <div className="form-group">
          <label htmlFor="name">Nom</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">Courriel</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="phone">Téléphone</label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="category">Type de demande</label>
          <select
            id="category"
            name="category"
            value={formData.category}
            onChange={handleChange}
            required
          >
            <option value="">Veuillez choisir</option>
            <option value="Information">Information sur un modèle</option>
            <option value="Service après‑vente">Service après‑vente</option>
            <option value="Demande de soumission">Demande de soumission</option>
            <option value="Autre">Autre</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="subject">Sujet</label>
          <input
            type="text"
            id="subject"
            name="subject"
            value={formData.subject}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="message">Message</label>
          <textarea
            id="message"
            name="message"
            value={formData.message}
            onChange={handleChange}
            required
          ></textarea>
        </div>
        <button type="submit" className="form-submit">
          Envoyer
        </button>
        {status === 'pending' && <p>Envoi en cours…</p>}
        {status === 'success' && <p>Merci! Votre message a été envoyé.</p>}
        {status === 'error' && <p>Une erreur est survenue, veuillez réessayer.</p>}
      </form>
    </Layout>
  );
}