import Head from 'next/head';
import Link from 'next/link';
import Layout from '../components/Layout';
import { getAllModels } from '../data/models';

export default function HomePage() {
  const models = getAllModels();
  return (
    <Layout>
      <Head>
        <title>Maisons S‑Turner | Accueil</title>
        <meta name="description" content="Maisons préfabriquées de qualité à Trois‑Rivières" />
      </Head>
      <section className="hero" style={{ backgroundImage: `url('/placeholder-hero.jpg')` }}>
        <h1>Votre maison de rêve sur mesure</h1>
        <p>
          Faites confiance à Maisons S‑Turner pour la conception et la fabrication de votre maison préfabriquée de qualité supérieure.
        </p>
        <Link href="/models" className="btn">
          Découvrir nos modèles
        </Link>
      </section>
      <h2 style={{ marginTop: '3rem' }}>Nos modèles en vedette</h2>
      <div className="grid">
        {models.map((model) => (
          <div key={model.slug} className="card">
            <img src={model.image} alt={model.name} />
            <div className="card-content">
              <div className="card-title">{model.name}</div>
              <div className="card-description">{model.description}</div>
              <div className="card-action">
                <Link href={`/models/${model.slug}`} className="btn">
                  Voir plus
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </Layout>
  );
}