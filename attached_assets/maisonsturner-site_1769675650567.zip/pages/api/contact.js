/**
 * API route to handle contact form submissions.
 * In a real application this endpoint could forward the message to a CRM or send an email.
 */
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end(`Méthode ${req.method} non autorisée`);
  }

  const { name, email, phone, subject, message, category } = req.body;
  // Basic validation
  if (!name || !email || !message) {
    return res.status(400).json({ error: 'Veuillez fournir les champs requis.' });
  }
  // TODO: Integrate with an email service or CRM.
  // For demonstration we simply log the submission on the server.
  console.log('Nouveau message reçu:', { name, email, phone, subject, message, category });

  return res.status(200).json({ success: true });
}