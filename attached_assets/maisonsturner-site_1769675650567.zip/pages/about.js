import Head from 'next/head';
import Layout from '../components/Layout';

export default function AboutPage() {
  return (
    <Layout>
      <Head>
        <title>À propos | Maisons S‑Turner</title>
        <meta name="description" content="En savoir plus sur la mission et l'histoire de Maisons S‑Turner." />
      </Head>
      <h1>À propos de nous</h1>
      <p>
        Depuis plus de 25 ans, Maisons S‑Turner conçoit et construit des maisons préfabriquées de qualité
        supérieure. Basés à Trois‑Rivières, nous mettons à profit notre savoir‑faire pour offrir des
        habitations durables, esthétiques et adaptées aux besoins de nos clients.
      </p>
      <h2>Notre mission</h2>
      <p>
        Notre mission est de simplifier le parcours de construction résidentielle en proposant des modèles
        modulaires flexibles et accessibles. Nous croyons qu'une maison doit être à la fois belle,
        fonctionnelle et abordable, et nous accompagnons nos clients à chaque étape du processus.
      </p>
      <h2>Notre histoire</h2>
      <p>
        Fondée par des passionnés de construction, l'entreprise a évolué au fil des années pour devenir un
        acteur incontournable dans l'industrie des maisons préfabriquées au Québec. Notre croissance s'est
        appuyée sur l'innovation, la qualité des matériaux et le service à la clientèle.
      </p>
      <h2>Nos valeurs</h2>
      <ul>
        <li>
          <strong>Intégrité :</strong> Nous faisons preuve de transparence et d'honnêteté dans chacune de nos
          relations.
        </li>
        <li>
          <strong>Engagement :</strong> Notre équipe s'engage à offrir un service de proximité et à respecter
          les délais.
        </li>
        <li>
          <strong>Esprit d'équipe :</strong> Nous valorisons la collaboration et le respect, tant au sein de
          l'entreprise qu'avec nos partenaires.
        </li>
      </ul>
    </Layout>
  );
}