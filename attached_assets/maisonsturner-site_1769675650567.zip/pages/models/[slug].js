import Head from 'next/head';
import Link from 'next/link';
import { useRouter } from 'next/router';
import Layout from '../../components/Layout';
import { getModelBySlug } from '../../data/models';

export default function ModelDetailPage() {
  const router = useRouter();
  const { slug } = router.query;
  const model = getModelBySlug(slug);

  if (!model) {
    return (
      <Layout>
        <p>Modèle introuvable.</p>
      </Layout>
    );
  }

  return (
    <Layout>
      <Head>
        <title>{model.name} | Maisons S‑Turner</title>
        <meta name="description" content={model.description} />
      </Head>
      <article>
        <h1>{model.name}</h1>
        <img src={model.image} alt={model.name} style={{ width: '100%', maxHeight: '300px', objectFit: 'cover', borderRadius: '6px' }} />
        <p style={{ marginTop: '1rem' }}>{model.description}</p>
        <h3>Caractéristiques</h3>
        <ul>
          {model.features.map((feat) => (
            <li key={feat}>{feat}</li>
          ))}
        </ul>
        <Link
          href={`/contact?model=${model.slug}`}
          className="btn"
          style={{ marginTop: '1rem', display: 'inline-block' }}
        >
          Obtenir une soumission
        </Link>
      </article>
    </Layout>
  );
}